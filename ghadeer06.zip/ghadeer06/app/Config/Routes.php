<?php

use CodeIgniter\Router\RouteCollection;

/** @var RouteCollection $routes */

// تسجيل الدخول
$routes->get('/', 'Auth::login');
$routes->get('/login', 'Auth::login');
$routes->post('/login', 'Auth::attemptLogin');
$routes->get('/logout', 'Auth::logout');

// صفحات الموظف (محمية بـ auth)
$routes->group('', ['filter' => 'auth'], function($routes) {
    $routes->get('/tickets', 'Tickets::index');
    $routes->get('/tickets/create', 'Tickets::create');
    $routes->post('/tickets/store', 'Tickets::store');
    $routes->get('/tickets/show/(:num)', 'Tickets::show/$1');
    $routes->post('/tickets/reply/(:num)', 'Tickets::reply/$1');
});

// صفحات التقني/الأدمن (محمية بـ admin)
$routes->group('admin', ['filter' => 'admin'], function($routes) {
    $routes->get('tickets', 'Admin::index');
    $routes->get('tickets/show/(:num)', 'Admin::show/$1');
    $routes->post('tickets/reply/(:num)', 'Admin::reply/$1');
});
