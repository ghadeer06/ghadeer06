<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>كل البلاغات | لوحة الدعم الفني</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <style>
        :root {
            --dark-green: #1a3c34;
            --gold: #c9a227;
            --gold-light: #e0c15c;
            --bg-light: #f4f6f5;
        }

        body { background: var(--bg-light); font-family: 'Segoe UI', Tahoma, sans-serif; }

        .navbar {
            background: var(--dark-green) !important;
            box-shadow: 0 2px 10px rgba(0,0,0,0.15);
            padding: 0.8rem 1.5rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .navbar-brand { color: var(--gold) !important; font-weight: 700; }
        .navbar span, .navbar strong { color: #ffffff !important; }

        .btn-outline-danger {
            color: var(--gold);
            border-color: var(--gold);
            background: transparent;
        }
        .btn-outline-danger:hover {
            background: var(--gold);
            border-color: var(--gold);
            color: var(--dark-green);
        }

        .card-box {
            border-radius: 12px;
            border: none;
            box-shadow: 0 2px 10px rgba(0,0,0,0.06);
            background: #fff;
        }

        h4 { color: var(--dark-green); font-weight: 700; }
        table th { color: var(--dark-green); font-weight: 700; border-bottom: 2px solid var(--gold); }

        .badge-priority-low { background: #6c757d; }
        .badge-priority-medium { background: var(--gold); color: var(--dark-green); }
        .badge-priority-high { background: #a33; }

        .badge-status-open { background: #0d6efd; }
        .badge-status-in_progress { background: var(--gold); color: var(--dark-green); }
        .badge-status-resolved { background: #198754; }

        .stat-mini {
            border-radius: 12px;
            border-top: 4px solid var(--gold);
            box-shadow: 0 2px 10px rgba(0,0,0,0.06);
            background: #fff;
            padding: 1.2rem;
            text-align: center;
        }
        .stat-mini h3 { color: #000; font-weight: 800; margin-bottom: 0.2rem; }
        .stat-mini p { color: #7a8a86; margin: 0; font-size: 0.9rem; }
    </style>
</head>
<body>

    <nav class="navbar navbar-expand-lg px-4 mb-4">
        <span class="navbar-brand fw-bold">لوحة الدعم الفني</span>
        <div class="d-flex align-items-center gap-3">
            <span>مرحبًا، <strong><?= esc(session()->get('name')) ?></strong></span>
            <a href="<?= site_url('logout') ?>" class="btn btn-outline-danger btn-sm">تسجيل الخروج</a>
        </div>
    </nav>

    <div class="container">

        <?php if (session()->getFlashdata('success')) : ?>
            <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
        <?php endif; ?>

        <?php
            $openCount = 0;
            $progressCount = 0;
            $resolvedCount = 0;

            foreach ($tickets as $t) {
                if ($t['status'] === 'open') {
                    $openCount++;
                } elseif ($t['status'] === 'in_progress') {
                    $progressCount++;
                } elseif ($t['status'] === 'resolved') {
                    $resolvedCount++;
                }
            }
        ?>

        <div class="row g-3 mb-4">
            <div class="col-md-4 col-4">
                <div class="stat-mini"><h3><?= $openCount ?></h3><p>بلاغات جديدة</p></div>
            </div>
            <div class="col-md-4 col-4">
                <div class="stat-mini"><h3><?= $progressCount ?></h3><p>قيد المعالجة</p></div>
            </div>
            <div class="col-md-4 col-4">
                <div class="stat-mini"><h3><?= $resolvedCount ?></h3><p>تم الحل</p></div>
            </div>
        </div>

        <h4 class="mb-3">كل البلاغات</h4>

        <div class="card card-box">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>العنوان</th>
                                <th>الموظف</th>
                                <th>الأولوية</th>
                                <th>الحالة</th>
                                <th>تاريخ الإرسال</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($tickets)) : ?>
                                <tr>
                                    <td colspan="7" class="text-center text-muted py-4">لا توجد بلاغات حتى الآن</td>
                                </tr>
                            <?php else : ?>
                                <?php foreach ($tickets as $ticket) : ?>
                                    <tr>
                                        <td>#<?= $ticket['id'] ?></td>
                                        <td><?= esc($ticket['title']) ?></td>
                                        <td><?= esc($ticket['employee_name']) ?></td>
                                        <td>
                                            <span class="badge badge-priority-<?= $ticket['priority'] ?>">
                                                <?= $ticket['priority'] === 'low' ? 'منخفضة' : ($ticket['priority'] === 'medium' ? 'متوسطة' : 'عالية') ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span class="badge badge-status-<?= $ticket['status'] ?>">
                                                <?= $ticket['status'] === 'open' ? 'جديد' : ($ticket['status'] === 'in_progress' ? 'قيد المعالجة' : 'تم الحل') ?>
                                            </span>
                                        </td>
                                        <td><?= date('Y-m-d H:i', strtotime($ticket['created_at'])) ?></td>
                                        <td>
                                            <a href="<?= site_url('admin/tickets/show/' . $ticket['id']) ?>"
                                               class="btn btn-sm btn-outline-primary">عرض ورد</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>

</body>
</html>