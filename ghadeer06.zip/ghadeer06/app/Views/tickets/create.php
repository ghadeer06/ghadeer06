<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>فتح بلاغ جديد | نظام البلاغات التقنية</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <style>
        :root {
            --dark-green: #1a3c34;
            --gold: #c9a227;
            --gold-light: #e0c15c;
            --bg-light: #f4f6f5;
        }

        body { background: var(--bg-light); font-family: 'Segoe UI', Tahoma, sans-serif; }

        .navbar {
            background: var(--dark-green) !important;
            box-shadow: 0 2px 10px rgba(0,0,0,0.15);
            padding: 0.8rem 1.5rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .navbar-brand { color: var(--gold) !important; font-weight: 700; }
        .navbar span, .navbar strong { color: #ffffff !important; }

        .btn-outline-danger {
            color: var(--gold);
            border-color: var(--gold);
            background: transparent;
        }
        .btn-outline-danger:hover {
            background: var(--gold);
            border-color: var(--gold);
            color: var(--dark-green);
        }

        .card-box {
            border-radius: 12px;
            border: none;
            border-top: 4px solid var(--gold);
            box-shadow: 0 2px 12px rgba(26,60,52,0.1);
            background: #fff;
            max-width: 600px;
            margin: 0 auto;
        }

        h4 { color: var(--dark-green); font-weight: 700; }
        .form-label { color: var(--dark-green); font-weight: 600; }

        .form-control:focus, .form-select:focus {
            border-color: var(--gold);
            box-shadow: 0 0 0 0.2rem rgba(201,162,39,0.25);
        }

        .btn-primary {
            background: var(--gold);
            border: none;
            color: var(--dark-green);
            font-weight: 600;
        }
        .btn-primary:hover { background: var(--gold-light); color: var(--dark-green); }
    </style>
</head>
<body>

    <nav class="navbar navbar-expand-lg px-4 mb-4">
        <span class="navbar-brand fw-bold">نظام البلاغات التقنية</span>
        <div class="d-flex align-items-center gap-3">
            <span>مرحبًا، <strong><?= esc(session()->get('name')) ?></strong></span>
            <a href="<?= site_url('logout') ?>" class="btn btn-outline-danger btn-sm">تسجيل الخروج</a>
        </div>
    </nav>

    <div class="container">

        <div class="d-flex justify-content-between align-items-center mb-4" style="max-width:600px; margin:0 auto;">
            <h4 class="m-0">فتح بلاغ جديد</h4>
            <a href="<?= site_url('tickets') ?>" class="btn btn-outline-secondary btn-sm">← رجوع</a>
        </div>

        <div class="card card-box">
            <div class="card-body p-4">

                <?php if (session()->getFlashdata('errors')) : ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0 ps-3">
                            <?php foreach (session()->getFlashdata('errors') as $error) : ?>
                                <li><?= esc($error) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form method="post" action="<?= site_url('tickets/store') ?>">
                    <?= csrf_field() ?>

                    <div class="mb-3">
                        <label class="form-label">عنوان البلاغ</label>
                        <input type="text" name="title" class="form-control"
                               placeholder="مثال: الطابعة لا تعمل" value="<?= old('title') ?>" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">تفاصيل المشكلة</label>
                        <textarea name="description" class="form-control" rows="5"
                                  placeholder="اشرحي المشكلة بالتفصيل..." required><?= old('description') ?></textarea>
                    </div>

                    <div class="mb-4">
                        <label class="form-label">الأولوية</label>
                        <select name="priority" class="form-select" required>
                            <option value="low" <?= old('priority') === 'low' ? 'selected' : '' ?>>منخفضة</option>
                            <option value="medium" <?= old('priority', 'medium') === 'medium' ? 'selected' : '' ?>>متوسطة</option>
                            <option value="high" <?= old('priority') === 'high' ? 'selected' : '' ?>>عالية (عاجل)</option>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-primary w-100">إرسال البلاغ</button>
                </form>

            </div>
        </div>

    </div>

</body>
</html>