<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>بلاغاتي | نظام البلاغات التقنية</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <style>
        :root {
            --dark-green: #1a3c34;
            --gold: #c9a227;
            --gold-light: #e0c15c;
            --bg-light: #f4f6f5;
        }

        body { background: var(--bg-light); font-family: 'Segoe UI', Tahoma, sans-serif; }

        .navbar {
            background: var(--dark-green) !important;
            box-shadow: 0 2px 10px rgba(0,0,0,0.15);
            padding: 0.8rem 1.5rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .navbar-brand { color: var(--gold) !important; font-weight: 700; }
        .navbar span, .navbar strong { color: #ffffff !important; }

        .btn-primary {
            background: var(--gold);
            border: none;
            color: var(--dark-green);
            font-weight: 600;
        }
        .btn-primary:hover { background: var(--gold-light); color: var(--dark-green); }

        .btn-outline-danger {
            color: var(--gold);
            border-color: var(--gold);
            background: transparent;
        }
        .btn-outline-danger:hover {
            background: var(--gold);
            border-color: var(--gold);
            color: var(--dark-green);
        }

        .card-box {
            border-radius: 12px;
            border: none;
            box-shadow: 0 2px 10px rgba(0,0,0,0.06);
            background: #fff;
        }

        h4 { color: var(--dark-green); font-weight: 700; }
        table th { color: var(--dark-green); font-weight: 700; border-bottom: 2px solid var(--gold); }

        .badge-priority-low { background: #6c757d; }
        .badge-priority-medium { background: var(--gold); color: var(--dark-green); }
        .badge-priority-high { background: #a33; }

        .badge-status-open { background: #0d6efd; }
        .badge-status-in_progress { background: var(--gold); color: var(--dark-green); }
        .badge-status-resolved { background: #198754; }
    </style>
</head>
<body>

    <nav class="navbar navbar-expand-lg px-4 mb-4">
        <span class="navbar-brand fw-bold">نظام البلاغات التقنية</span>
        <div class="d-flex align-items-center gap-3">
            <span>مرحبًا، <strong><?= esc(session()->get('name')) ?></strong></span>
            <a href="<?= site_url('logout') ?>" class="btn btn-outline-danger btn-sm">تسجيل الخروج</a>
        </div>
    </nav>

    <div class="container">

        <?php if (session()->getFlashdata('success')) : ?>
            <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
        <?php endif; ?>

        <?php if (session()->getFlashdata('error')) : ?>
            <div class="alert alert-danger"><?= session()->getFlashdata('error') ?></div>
        <?php endif; ?>

        <div class="d-flex justify-content-between align-items-center mb-4">
            <h4 class="m-0">بلاغاتي</h4>
            <a href="<?= site_url('tickets/create') ?>" class="btn btn-primary">
                + فتح بلاغ جديد
            </a>
        </div>

        <div class="card card-box">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>العنوان</th>
                                <th>الأولوية</th>
                                <th>الحالة</th>
                                <th>تاريخ الإرسال</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($tickets)) : ?>
                                <tr>
                                    <td colspan="6" class="text-center text-muted py-4">
                                        ما عندك بلاغات حتى الآن
                                    </td>
                                </tr>
                            <?php else : ?>
                                <?php foreach ($tickets as $ticket) : ?>
                                    <tr>
                                        <td>#<?= $ticket['id'] ?></td>
                                        <td><?= esc($ticket['title']) ?></td>
                                        <td>
                                            <span class="badge badge-priority-<?= $ticket['priority'] ?>">
                                                <?= $ticket['priority'] === 'low' ? 'منخفضة' : ($ticket['priority'] === 'medium' ? 'متوسطة' : 'عالية') ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span class="badge badge-status-<?= $ticket['status'] ?>">
                                                <?= $ticket['status'] === 'open' ? 'جديد' : ($ticket['status'] === 'in_progress' ? 'قيد المعالجة' : 'تم الحل') ?>
                                            </span>
                                        </td>
                                        <td><?= date('Y-m-d H:i', strtotime($ticket['created_at'])) ?></td>
                                        <td>
                                            <a href="<?= site_url('tickets/show/' . $ticket['id']) ?>"
                                               class="btn btn-sm btn-outline-primary">عرض</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>

</body>
</html>