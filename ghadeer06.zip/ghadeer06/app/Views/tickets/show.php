<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>تفاصيل البلاغ | نظام البلاغات التقنية</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <style>
        :root {
            --dark-green: #1a3c34;
            --gold: #c9a227;
            --gold-light: #e0c15c;
            --bg-light: #f4f6f5;
        }

        body { background: var(--bg-light); font-family: 'Segoe UI', Tahoma, sans-serif; }

        .navbar {
            background: var(--dark-green) !important;
            box-shadow: 0 2px 10px rgba(0,0,0,0.15);
            padding: 0.8rem 1.5rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .navbar-brand { color: var(--gold) !important; font-weight: 700; }
        .navbar span, .navbar strong { color: #ffffff !important; }

        .btn-outline-danger {
            color: var(--gold);
            border-color: var(--gold);
            background: transparent;
        }
        .btn-outline-danger:hover {
            background: var(--gold);
            border-color: var(--gold);
            color: var(--dark-green);
        }

        .card-box {
            border-radius: 12px;
            border: none;
            border-top: 4px solid var(--gold);
            box-shadow: 0 2px 12px rgba(26,60,52,0.1);
            background: #fff;
            max-width: 700px;
            margin: 0 auto;
        }

        h4, h5 { color: var(--dark-green); font-weight: 700; }

        .badge-priority-low { background: #6c757d; }
        .badge-priority-medium { background: var(--gold); color: var(--dark-green); }
        .badge-priority-high { background: #a33; }

        .badge-status-open { background: #0d6efd; }
        .badge-status-in_progress { background: var(--gold); color: var(--dark-green); }
        .badge-status-resolved { background: #198754; }

        .reply-box {
            border-radius: 10px;
            padding: 12px 15px;
            margin-bottom: 10px;
            background: var(--bg-light);
            border-right: 3px solid var(--gold);
        }
        .reply-box.is-admin {
            border-right-color: var(--dark-green);
            background: #eef5f3;
        }
        .reply-box small { color: #888; }

        .form-control:focus {
            border-color: var(--gold);
            box-shadow: 0 0 0 0.2rem rgba(201,162,39,0.25);
        }

        .btn-primary {
            background: var(--gold);
            border: none;
            color: var(--dark-green);
            font-weight: 600;
        }
        .btn-primary:hover { background: var(--gold-light); color: var(--dark-green); }
    </style>
</head>
<body>

    <nav class="navbar navbar-expand-lg px-4 mb-4">
        <span class="navbar-brand fw-bold">نظام البلاغات التقنية</span>
        <div class="d-flex align-items-center gap-3">
            <span>مرحبًا، <strong><?= esc(session()->get('name')) ?></strong></span>
            <a href="<?= site_url('logout') ?>" class="btn btn-outline-danger btn-sm">تسجيل الخروج</a>
        </div>
    </nav>

    <div class="container">

        <div class="d-flex justify-content-between align-items-center mb-4" style="max-width:700px; margin:0 auto;">
            <h4 class="m-0">تفاصيل البلاغ #<?= $ticket['id'] ?></h4>
            <a href="<?= site_url('tickets') ?>" class="btn btn-outline-secondary btn-sm">← رجوع</a>
        </div>

        <div class="card card-box mb-3">
            <div class="card-body p-4">
                <div class="d-flex justify-content-between align-items-start mb-3">
                    <h5 class="m-0"><?= esc($ticket['title']) ?></h5>
                    <div class="d-flex gap-2">
                        <span class="badge badge-priority-<?= $ticket['priority'] ?>">
                            <?= $ticket['priority'] === 'low' ? 'منخفضة' : ($ticket['priority'] === 'medium' ? 'متوسطة' : 'عالية') ?>
                        </span>
                        <span class="badge badge-status-<?= $ticket['status'] ?>">
                            <?= $ticket['status'] === 'open' ? 'جديد' : ($ticket['status'] === 'in_progress' ? 'قيد المعالجة' : 'تم الحل') ?>
                        </span>
                    </div>
                </div>
                <p class="text-muted mb-0"><?= nl2br(esc($ticket['description'])) ?></p>
                <small class="text-muted">تاريخ الإرسال: <?= date('Y-m-d H:i', strtotime($ticket['created_at'])) ?></small>
            </div>
        </div>

        <div class="card card-box mb-3">
            <div class="card-body p-4">
                <h5 class="mb-3">المحادثة</h5>

                <?php if (empty($replies)) : ?>
                    <p class="text-muted">لا توجد ردود حتى الآن</p>
                <?php else : ?>
                    <?php foreach ($replies as $reply) : ?>
                        <div class="reply-box <?= $reply['user_id'] != session()->get('user_id') ? 'is-admin' : '' ?>">
                            <?= nl2br(esc($reply['message'])) ?>
                            <br><small><?= date('Y-m-d H:i', strtotime($reply['created_at'])) ?></small>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>