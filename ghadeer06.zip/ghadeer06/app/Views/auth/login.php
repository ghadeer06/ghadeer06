<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>تسجيل الدخول | نظام البلاغات التقنية</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <style>
        :root {
            --dark-green: #1a3c34;
            --gold: #c9a227;
            --gold-light: #e0c15c;
            --bg-light: #f4f6f5;
        }

        body {
            background: var(--bg-light);
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Segoe UI', Tahoma, sans-serif;
            margin: 0;
        }

        .login-card {
            width: 100%;
            max-width: 400px;
            padding: 2.5rem;
            border-radius: 12px;
            border-top: 4px solid var(--gold);
            box-shadow: 0 4px 20px rgba(26,60,52,0.15);
            background: #fff;
        }

        .login-card h3 {
            font-weight: 700;
            margin-bottom: 0.3rem;
            text-align: center;
            color: var(--dark-green);
        }

        .login-card p.subtitle {
            text-align: center;
            color: #888;
            margin-bottom: 1.5rem;
            font-size: 0.9rem;
        }

        .form-label {
            color: var(--dark-green);
            font-weight: 600;
        }

        .form-control:focus {
            border-color: var(--gold);
            box-shadow: 0 0 0 0.2rem rgba(201,162,39,0.25);
        }

        .btn-primary {
            width: 100%;
            padding: 10px;
            font-weight: 600;
            background: var(--gold);
            border: none;
            color: var(--dark-green);
        }
        .btn-primary:hover {
            background: var(--gold-light);
            color: var(--dark-green);
        }
    </style>
</head>
<body>

    <div class="login-card">
        <h3>نظام البلاغات التقنية</h3>
        <p class="subtitle">تسجيل الدخول للموظفين والدعم الفني</p>

        <?php if (session()->getFlashdata('error')) : ?>
            <div class="alert alert-danger py-2"><?= session()->getFlashdata('error') ?></div>
        <?php endif; ?>

        <?php if (session()->getFlashdata('success')) : ?>
            <div class="alert alert-success py-2"><?= session()->getFlashdata('success') ?></div>
        <?php endif; ?>

        <form method="post" action="<?= site_url('login') ?>">
            <?= csrf_field() ?>

            <div class="mb-3">
                <label class="form-label">البريد الإلكتروني</label>
                <input type="email" name="email" class="form-control"
                       value="<?= old('email') ?>" required autofocus>
            </div>

            <div class="mb-3">
                <label class="form-label">كلمة المرور</label>
                <input type="password" name="password" class="form-control" required>
            </div>

            <button type="submit" class="btn btn-primary">تسجيل الدخول</button>
        </form>
    </div>

</body>
</html>