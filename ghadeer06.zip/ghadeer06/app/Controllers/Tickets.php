<?php

namespace App\Controllers;

use App\Models\TicketModel;
use App\Models\TicketReplyModel;

class Tickets extends BaseController
{
    protected $ticketModel;
    protected $replyModel;

    public function __construct()
    {
        $this->ticketModel = new TicketModel();
        $this->replyModel  = new TicketReplyModel();
    }

    // قائمة بلاغات الموظف الحالي فقط
    public function index()
    {
        $data['tickets'] = $this->ticketModel
            ->where('created_by', session()->get('user_id'))
            ->orderBy('created_at', 'DESC')
            ->findAll();

        return view('tickets/index', $data);
    }

    // نموذج فتح بلاغ جديد
    public function create()
    {
        return view('tickets/create');
    }

    // حفظ بلاغ جديد
    public function store()
    {
        $rules = [
            'title'       => 'required|min_length[5]|max_length[255]',
            'description' => 'required|min_length[10]',
            'priority'    => 'required|in_list[low,medium,high]',
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $this->ticketModel->save([
            'title'       => $this->request->getPost('title'),
            'description' => $this->request->getPost('description'),
            'priority'    => $this->request->getPost('priority'),
            'status'      => 'open',
            'created_by'  => session()->get('user_id'),
        ]);

        return redirect()->to('/tickets')->with('success', 'تم إرسال البلاغ بنجاح');
    }

    // تفاصيل بلاغ + المحادثة
    public function show($id)
    {
        $ticket = $this->ticketModel->find($id);

        if (!$ticket || $ticket['created_by'] != session()->get('user_id')) {
            return redirect()->to('/tickets')->with('error', 'البلاغ غير موجود');
        }

        $data['ticket']  = $ticket;
        $data['replies'] = $this->replyModel
            ->where('ticket_id', $id)
            ->orderBy('created_at', 'ASC')
            ->findAll();

        return view('tickets/show', $data);
    }

    // إضافة رد من الموظف
    public function reply($id)
    {
        $ticket = $this->ticketModel->find($id);

        if (!$ticket || $ticket['created_by'] != session()->get('user_id')) {
            return redirect()->to('/tickets')->with('error', 'البلاغ غير موجود');
        }

        $message = $this->request->getPost('message');

        if (!empty($message)) {
            $this->replyModel->save([
                'ticket_id' => $id,
                'user_id'   => session()->get('user_id'),
                'message'   => $message,
            ]);
        }

        return redirect()->to('/tickets/show/' . $id);
    }
}