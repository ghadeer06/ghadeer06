<?php

namespace App\Controllers;

use App\Models\TicketModel;
use App\Models\TicketReplyModel;
use App\Models\UserModel;

class Admin extends BaseController
{
    protected $ticketModel;
    protected $replyModel;
    protected $userModel;

    public function __construct()
    {
        $this->ticketModel = new TicketModel();
        $this->replyModel  = new TicketReplyModel();
        $this->userModel   = new UserModel();
    }

    // كل البلاغات من كل الموظفين
    public function index()
    {

        $data['tickets'] = $this->ticketModel
            ->select('tickets.*, users.name as employee_name')
            ->join('users', 'users.id = tickets.created_by')
            ->orderBy('tickets.created_at', 'DESC')
            ->findAll();

        return view('admin/index', $data);
    }

    // تفاصيل بلاغ معيّن + الرد + تغيير الحالة
    public function show($id)
    {
        $ticket = $this->ticketModel
            ->select('tickets.*, users.name as employee_name')
            ->join('users', 'users.id = tickets.created_by')
            ->where('tickets.id', $id)
            ->first();

        if (!$ticket) {
            return redirect()->to('/admin/tickets')->with('error', 'البلاغ غير موجود');
        }

        $data['ticket']  = $ticket;
        $data['replies'] = $this->replyModel
            ->where('ticket_id', $id)
            ->orderBy('created_at', 'ASC')
            ->findAll();

        return view('admin/show', $data);
    }

    // رد التقني + تحديث الحالة
    public function reply($id)
    {
        $ticket = $this->ticketModel->find($id);

        if (!$ticket) {
            return redirect()->to('/admin/tickets')->with('error', 'البلاغ غير موجود');
        }

        $message = $this->request->getPost('message');
        $status  = $this->request->getPost('status');

        if (!empty($message)) {
            $this->replyModel->save([
                'ticket_id' => $id,
                'user_id'   => session()->get('user_id'),
                'message'   => $message,
            ]);
        }

        if (!empty($status) && in_array($status, ['open', 'in_progress', 'resolved'])) {
            $this->ticketModel->update($id, [
                'status'      => $status,
                'assigned_to' => session()->get('user_id'),
            ]);
        }

        return redirect()->to('/admin/tickets/show/' . $id)->with('success', 'تم التحديث بنجاح');
    }
}